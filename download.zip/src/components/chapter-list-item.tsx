'use client';

import Link from 'next/link';
import { Book, CheckCircle2, Circle } from 'lucide-react';
import type { Chapter } from '@/lib/data';
import { useProgress } from '@/hooks/use-progress';
import { useMemo } from 'react';

type ChapterListItemProps = {
  subjectId: string;
  chapter: Chapter;
};

export default function ChapterListItem({ subjectId, chapter }: ChapterListItemProps) {
  const lectureIds = useMemo(() => chapter.lectures.map(l => l.id), [chapter.lectures]);
  const { isComplete, isLoading } = useProgress(0); // Total lectures don't matter here

  const isChapterComplete = useMemo(() => {
    if (isLoading || lectureIds.length === 0) return false;
    return lectureIds.every(id => isComplete(id));
  }, [isLoading, lectureIds, isComplete]);

  return (
    <Link href={`/subjects/${subjectId}/${chapter.id}`} className="block">
      <div className="border rounded-lg p-4 transition-all duration-300 hover:bg-primary/5 hover:shadow-md hover:border-primary/30 flex items-center gap-4">
        <div className="flex-shrink-0 text-primary">
          {isLoading ? <Circle className="h-6 w-6 animate-pulse" /> :
           isChapterComplete ? 
           <CheckCircle2 className="h-6 w-6 text-green-500" /> : 
           <Book className="h-6 w-6" />}
        </div>
        <div className="flex-grow">
          <h3 className="text-lg font-semibold font-headline">{chapter.title}</h3>
          <p className="text-sm text-muted-foreground">{chapter.description}</p>
        </div>
        <div className="flex-shrink-0 ml-4">
          <span className="text-xs bg-secondary text-secondary-foreground rounded-full px-2 py-1">
            {chapter.lectures.length} {chapter.lectures.length === 1 ? 'Lecture' : 'Lectures'}
          </span>
        </div>
      </div>
    </Link>
  );
}
