'use client';

import { useState } from 'react';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { Chapter, Lecture } from '@/lib/data';
import { useProgress } from '@/hooks/use-progress';
import { PlayCircle, FileText, HelpCircle, CheckCircle2, Circle } from 'lucide-react';

export default function LectureView({ chapter }: { chapter: Chapter }) {
  const [currentLecture, setCurrentLecture] = useState<Lecture>(chapter.lectures[0]);
  const { toggleComplete, isComplete, isLoading } = useProgress(0);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2">
        <Card className="overflow-hidden">
          <div className="aspect-video bg-black">
            {currentLecture && (
              <iframe
                className="w-full h-full"
                src={`https://www.youtube.com/embed/${currentLecture.videoId}?autoplay=1&modestbranding=1&rel=0`}
                title={currentLecture.title}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            )}
          </div>
        </Card>
        <div className="mt-4">
          <h2 className="text-2xl font-bold font-headline">{currentLecture?.title}</h2>
        </div>
      </div>
      
      <div className="lg:col-span-1">
        <Tabs defaultValue="lectures" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="lectures"><PlayCircle className="mr-2 h-4 w-4" />Lectures</TabsTrigger>
            <TabsTrigger value="notes"><FileText className="mr-2 h-4 w-4" />Notes</TabsTrigger>
            <TabsTrigger value="quiz"><HelpCircle className="mr-2 h-4 w-4" />Quiz</TabsTrigger>
          </TabsList>
          
          <TabsContent value="lectures">
            <Card>
              <CardContent className="p-0">
                <ScrollArea className="h-96">
                  <div className="p-4 space-y-2">
                    {chapter.lectures.map((lecture) => (
                      <div
                        key={lecture.id}
                        onClick={() => setCurrentLecture(lecture)}
                        className={`p-3 rounded-lg cursor-pointer flex items-center gap-4 transition-colors ${
                          currentLecture.id === lecture.id
                            ? 'bg-primary/10 text-primary'
                            : 'hover:bg-muted'
                        }`}
                      >
                        {isLoading ? <Circle className="h-5 w-5 text-muted-foreground animate-pulse" /> : 
                          isComplete(lecture.id) ? 
                          <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0"/> :
                          <PlayCircle className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                        }
                        <span className="flex-grow font-medium">{lecture.title}</span>
                        <Checkbox
                          id={`cb-${lecture.id}`}
                          checked={!isLoading && isComplete(lecture.id)}
                          onCheckedChange={() => toggleComplete(lecture.id)}
                          onClick={(e) => e.stopPropagation()}
                          aria-label={`Mark ${lecture.title} as complete`}
                        />
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="notes">
            <Card>
                <CardContent className="p-6 h-96">
                    <h3 className="font-headline text-lg mb-4">Chapter Notes</h3>
                    {chapter.notes ? (
                        <p>{chapter.notes}</p>
                    ) : (
                        <p className="text-muted-foreground">No notes available for this chapter yet.</p>
                    )}
                </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="quiz">
            <Card>
                <CardContent className="p-6 h-96">
                    <h3 className="font-headline text-lg mb-4">Chapter Quiz</h3>
                     {chapter.quiz ? (
                        <p>Quiz functionality will be implemented here.</p>
                    ) : (
                        <p className="text-muted-foreground">No quiz available for this chapter yet.</p>
                    )}
                </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
