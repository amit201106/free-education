import Link from 'next/link';
import Image from 'next/image';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import type { Subject } from '@/lib/data';
import { ArrowRight } from 'lucide-react';
import { PlaceHolderImages } from '@/lib/placeholder-images';

export default function SubjectCard({ subject }: { subject: Subject }) {
  const image = PlaceHolderImages.find(img => img.id === subject.imageId);

  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-xl hover:border-primary/50 group">
      <CardHeader className="p-0">
        {image && (
          <div className="relative h-48 w-full">
            <Image
              src={image.imageUrl}
              alt={image.description}
              fill
              className="object-cover transition-transform duration-300 group-hover:scale-105"
              data-ai-hint={image.imageHint}
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            />
             <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
          </div>
        )}
      </CardHeader>
      <CardContent className="p-6">
        <div className="flex items-start gap-4 mb-4">
          <div className="bg-primary/10 text-primary p-3 rounded-lg">
             <subject.icon className="h-8 w-8" />
          </div>
          <div>
            <CardTitle className="font-headline text-2xl">{subject.name_hi}</CardTitle>
            <p className="text-sm text-muted-foreground">{subject.name}</p>
          </div>
        </div>
        <p className="mb-6 text-sm text-muted-foreground">
          Explore {subject.chapters.length} chapters filled with video lectures and notes.
        </p>
        <Button asChild className="w-full bg-primary/90 hover:bg-primary text-primary-foreground">
          <Link href={`/subjects/${subject.id}`}>
            View Chapters <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </CardContent>
    </Card>
  );
}
