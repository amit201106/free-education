'use client';

import { useProgress } from '@/hooks/use-progress';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Skeleton } from './ui/skeleton';

export default function ProgressSummary({ totalLectures }: { totalLectures: number }) {
  const { completedCount, progressPercentage, isLoading } = useProgress(totalLectures);

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-1/2" />
          <Skeleton className="h-4 w-1/3 mt-2" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-4 w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card/90 backdrop-blur-sm border-2 border-primary/20 shadow-lg">
      <CardHeader>
        <CardTitle className="font-headline text-2xl">Your Progress</CardTitle>
        <CardDescription className="text-base">
          You have completed <strong>{completedCount}</strong> out of <strong>{totalLectures}</strong> lectures. Keep up the great work!
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Progress value={progressPercentage} className="h-3" aria-label={`${Math.round(progressPercentage)}% complete`} />
        <p className="text-right text-sm text-muted-foreground mt-2">{Math.round(progressPercentage)}% Complete</p>
      </CardContent>
    </Card>
  );
}
