import { Calculator, FlaskConical, Landmark, BookText, SpellCheck, Milestone } from 'lucide-react';

export type Lecture = {
  id: string;
  title: string;
  videoId: string;
};

export type Chapter = {
  id: string;
  title: string;
  description: string;
  lectures: Lecture[];
  notes?: string;
  quiz?: {
    question: string;
    options: string[];
    correctAnswer: number;
  }[];
};

export type Subject = {
  id: string;
  name: string;
  name_hi: string;
  icon: React.ComponentType<{ className?: string }>;
  imageId: string;
  chapters: Chapter[];
};

export const subjects: Subject[] = [
  {
    id: 'maths',
    name: 'Mathematics',
    name_hi: 'गणित',
    icon: Calculator,
    imageId: 'maths-hero',
    chapters: [
      {
        id: 'real-numbers',
        title: 'वास्तविक संख्याएँ',
        description: 'अंकगणित की आधारभूत प्रमेय, अपरिमेय संख्याओं का पुनर्भ्रमण',
        lectures: [
          { id: 'm-c1-l1', title: 'परिचय: वास्तविक संख्याएँ', videoId: 'gA5H9tF-g_s' },
          { id: 'm-c1-l2', title: 'यूक्लिड विभाजन प्रमेयिका', videoId: '5gP2YI4L9yY' },
        ],
      },
      {
        id: 'polynomials',
        title: 'बहुपद',
        description: 'बहुपद के शून्यांक, शून्यांकों और गुणांकों में संबंध',
        lectures: [
          { id: 'm-c2-l1', title: 'बहुपदों का परिचय', videoId: 'TXJQGA6eO2c' },
        ],
      },
    ],
  },
  {
    id: 'science',
    name: 'Science',
    name_hi: 'विज्ञान',
    icon: FlaskConical,
    imageId: 'science-hero',
    chapters: [
      {
        id: 'chemical-reactions',
        title: 'रासायनिक अभिक्रियाएँ एवं समीकरण',
        description: 'रासायनिक समीकरण, संयोजन, वियोजन, विस्थापन अभिक्रियाएं',
        lectures: [
          { id: 's-c1-l1', title: 'रासायनिक अभिक्रिया का परिचय', videoId: 'BwuYu5i23-o' },
          { id: 's-c1-l2', title: 'रासायनिक समीकरण को संतुलित करना', videoId: 'tAig822Vz6A' },
        ],
      },
      {
        id: 'acids-bases-salts',
        title: 'अम्ल, क्षारक एवं लवण',
        description: 'अम्ल और क्षारक के रासायनिक गुणधर्म, pH स्केल',
        lectures: [
          { id: 's-c2-l1', title: 'अम्ल एवं क्षारक की पहचान', videoId: '6LpTqjM2m7k' },
        ],
      },
    ],
  },
  {
    id: 'sst',
    name: 'Social Science',
    name_hi: 'सामाजिक विज्ञान',
    icon: Landmark,
    imageId: 'sst-hero',
    chapters: [
      {
        id: 'rise-of-nationalism-in-europe',
        title: 'यूरोप में राष्ट्रवाद का उदय',
        description: 'फ्रांसीसी क्रांति और राष्ट्र का विचार, राष्ट्रवाद का निर्माण',
        lectures: [
          { id: 'sst-c1-l1', title: 'यूरोप में राष्ट्रवाद का परिचय', videoId: 'CHs_gGpw23c' },
        ],
      },
    ],
  },
  {
    id: 'hindi',
    name: 'Hindi',
    name_hi: 'हिन्दी',
    icon: BookText,
    imageId: 'hindi-hero',
    chapters: [
      {
        id: 'surdas-ke-pad',
        title: 'सूरदास के पद',
        description: 'उद्धव और गोपियों का संवाद, प्रेम की महत्ता',
        lectures: [
          { id: 'h-c1-l1', title: 'सूरदास के पद की व्याख्या', videoId: 'kPizq9h2T5M' },
        ],
      },
    ],
  },
  {
    id: 'english',
    name: 'English',
    name_hi: 'अंग्रेज़ी',
    icon: SpellCheck,
    imageId: 'english-hero',
    chapters: [
      {
        id: 'a-letter-to-god',
        title: 'A Letter to God',
        description: 'A story of immense faith in God.',
        lectures: [
          { id: 'e-c1-l1', title: 'A Letter to God - Summary and Explanation', videoId: 'mS5x4Q_aRR0' },
        ],
      },
    ],
  },
  {
    id: 'sanskrit',
    name: 'Sanskrit',
    name_hi: 'संस्कृत',
    icon: Milestone,
    imageId: 'sanskrit-hero',
    chapters: [
      {
        id: 'mangalampath',
        title: 'मङ्गलम् पाठ',
        description: 'उपनिषदों से संकलित मंगलाचरण',
        lectures: [
          { id: 'san-c1-l1', title: 'मङ्गलम् पाठ की व्याख्या', videoId: 'p2j9L3i4qfY' },
        ],
      },
    ],
  },
];

export function getTotalLectures() {
  return subjects.reduce((total, subject) => {
    return total + subject.chapters.reduce((subTotal, chapter) => subTotal + chapter.lectures.length, 0);
  }, 0);
}

export function getSubjectById(subjectId: string) {
  return subjects.find(subject => subject.id === subjectId);
}

export function getChapterById(subjectId: string, chapterId: string) {
  const subject = getSubjectById(subjectId);
  return subject?.chapters.find(chapter => chapter.id === chapterId);
}
