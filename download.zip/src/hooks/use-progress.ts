'use client';

import { useState, useEffect, useCallback } from 'react';

const PROGRESS_KEY = 'boardprep-progress';

export function useProgress(totalLectures: number) {
  const [completedLectures, setCompletedLectures] = useState<Set<string>>(new Set());
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    try {
      const storedProgress = localStorage.getItem(PROGRESS_KEY);
      if (storedProgress) {
        setCompletedLectures(new Set(JSON.parse(storedProgress)));
      }
    } catch (error) {
      console.error("Failed to load progress from localStorage", error);
    }
    setIsMounted(true);
  }, []);

  useEffect(() => {
    if (isMounted) {
      try {
        localStorage.setItem(PROGRESS_KEY, JSON.stringify(Array.from(completedLectures)));
      } catch (error) {
        console.error("Failed to save progress to localStorage", error);
      }
    }
  }, [completedLectures, isMounted]);

  const toggleComplete = useCallback((lectureId: string) => {
    setCompletedLectures(prev => {
      const newProgress = new Set(prev);
      if (newProgress.has(lectureId)) {
        newProgress.delete(lectureId);
      } else {
        newProgress.add(lectureId);
      }
      return newProgress;
    });
  }, []);

  const isComplete = useCallback((lectureId: string) => {
    return completedLectures.has(lectureId);
  }, [completedLectures]);
  
  const progressPercentage = totalLectures > 0 ? (completedLectures.size / totalLectures) * 100 : 0;

  if (!isMounted) {
    return {
      completedCount: 0,
      progressPercentage: 0,
      toggleComplete: () => {},
      isComplete: () => false,
      isLoading: true,
    };
  }

  return {
    completedCount: completedLectures.size,
    progressPercentage,
    toggleComplete,
    isComplete,
    isLoading: false,
  };
}
