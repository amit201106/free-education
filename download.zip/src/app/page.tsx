import Header from '@/components/header';
import ProgressSummary from '@/components/progress-summary';
import SubjectCard from '@/components/subject-card';
import { subjects, getTotalLectures } from '@/lib/data';

export default function HomePage() {
  const totalLectures = getTotalLectures();

  return (
    <div className="min-h-screen w-full bg-background flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8 md:px-6">
        <section className="mb-12 text-center">
          <h1 className="text-4xl font-bold font-headline tracking-tight md:text-5xl lg:text-6xl mb-4 animate-fade-in-down">
            Welcome to <span className="text-primary">BoardPrep Bihar</span>
          </h1>
          <p className="max-w-3xl mx-auto text-lg text-muted-foreground md:text-xl animate-fade-in-up">
            Your one-stop platform for Bihar Board Class 10 preparation. Ace your exams with our curated video lectures, notes, and quizzes.
          </p>
          <div className="mt-8 max-w-2xl mx-auto">
            <ProgressSummary totalLectures={totalLectures} />
          </div>
        </section>

        <section>
          <h2 className="text-3xl font-bold font-headline mb-8 text-center">Explore Subjects</h2>
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {subjects.map((subject, index) => (
              <div key={subject.id} className="animate-fade-in-up" style={{ animationDelay: `${index * 100}ms` }}>
                <SubjectCard subject={subject} />
              </div>
            ))}
          </div>
        </section>
      </main>
      <footer className="py-6 border-t mt-12">
          <div className="container mx-auto px-4 md:px-6 text-center text-muted-foreground">
              <p>&copy; {new Date().getFullYear()} BoardPrep Bihar. All rights reserved.</p>
          </div>
      </footer>
    </div>
  );
}
