'use client';

import { useState } from 'react';
import { subjects as initialSubjects, type Subject, type Chapter, type Lecture } from '@/lib/data';
import { Button } from '@/components/ui/button';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { PlusCircle, Edit, Trash2, Book, FileVideo } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';


type EditableItem = {
    type: 'Subject' | 'Chapter' | 'Lecture';
    subjectId: string;
    chapterId?: string;
    lectureId?: string;
    data: Subject | Chapter | Lecture | null;
};

type AddLectureState = {
    open: boolean;
    subjectId: string;
    chapterId: string;
};

type AddChapterState = {
    open: boolean;
    subjectId: string;
};


export default function AdminDashboard() {
  const [subjects, setSubjects] = useState<Subject[]>(initialSubjects);
  const { toast } = useToast();
  const [editItem, setEditItem] = useState<EditableItem | null>(null);
  const [editedVideoUrl, setEditedVideoUrl] = useState('');

  const [addLectureState, setAddLectureState] = useState<AddLectureState | null>(null);
  const [newLectureTitle, setNewLectureTitle] = useState('');
  const [newLectureLink, setNewLectureLink] = useState('');
  
  const [addChapterState, setAddChapterState] = useState<AddChapterState | null>(null);
  const [newChapterTitle, setNewChapterTitle] = useState('');


  const getYoutubeVideoId = (url: string) => {
    if(!url) return '';
    try {
        const urlObj = new URL(url);
        if (urlObj.hostname === 'youtu.be') {
            return urlObj.pathname.slice(1);
        }
        if (urlObj.hostname.includes('youtube.com')) {
            return urlObj.searchParams.get('v') || '';
        }
    } catch (e) {
        // Not a valid URL, maybe it's just an ID
        return url;
    }
    return '';
  }

  const handleAddSubject = () => {
    // In a real app, this would open a form and then make an API call.
    toast({
      title: "Feature not implemented",
      description: "Adding new subjects is a planned feature.",
    });
  };
  
  const handleOpenAddLecture = (subjectId: string, chapterId: string) => {
    setAddLectureState({ open: true, subjectId, chapterId });
  };

  const handleCloseAddLecture = () => {
    setAddLectureState(null);
    setNewLectureTitle('');
    setNewLectureLink('');
  };

  const handleAddLecture = () => {
    if (!addLectureState || !newLectureTitle || !newLectureLink) {
        toast({ variant: 'destructive', title: "Please fill all fields." });
        return;
    }

    const videoId = getYoutubeVideoId(newLectureLink);
    if (!videoId) {
        toast({ variant: 'destructive', title: 'Invalid YouTube URL' });
        return;
    }

    const newLecture: Lecture = {
        id: `l-${Date.now()}`,
        title: newLectureTitle,
        videoId: videoId,
    };

    const newSubjects = subjects.map(s => {
        if (s.id === addLectureState.subjectId) {
            return {
                ...s,
                chapters: s.chapters.map(c => {
                    if (c.id === addLectureState.chapterId) {
                        return { ...c, lectures: [...c.lectures, newLecture] };
                    }
                    return c;
                })
            };
        }
        return s;
    });

    setSubjects(newSubjects);
    toast({ title: 'Lecture Added', description: `"${newLecture.title}" has been added.` });
    handleCloseAddLecture();
  };


  const handleEdit = (item: EditableItem) => {
    setEditItem(item);
    if(item.type === 'Lecture' && item.data){
        setEditedVideoUrl(`https://www.youtube.com/watch?v=${(item.data as Lecture).videoId}`);
    }
  };

  const handleDelete = (type: 'Lecture', subjectId: string, chapterId: string, lectureId: string) => {
    let lectureTitle = '';
    const newSubjects = subjects.map(s => {
        if (s.id === subjectId) {
            return {
                ...s,
                chapters: s.chapters.map(c => {
                    if (c.id === chapterId) {
                        const lectureToDelete = c.lectures.find(l => l.id === lectureId);
                        if (lectureToDelete) lectureTitle = lectureToDelete.title;

                        return {
                            ...c,
                            lectures: c.lectures.filter(l => l.id !== lectureId)
                        };
                    }
                    return c;
                })
            };
        }
        return s;
    });

    setSubjects(newSubjects);
    toast({
        title: "Lecture Deleted",
        description: `Lecture "${lectureTitle}" has been removed.`,
        variant: "destructive"
    });
  };

  const handleSaveEdit = () => {
    if(!editItem || !editItem.data) return;

    if(editItem.type === 'Lecture') {
        const { subjectId, chapterId, lectureId } = editItem;
        const videoId = getYoutubeVideoId(editedVideoUrl);

        if (!videoId) {
            toast({
                variant: "destructive",
                title: "Invalid YouTube URL",
                description: "Please enter a valid YouTube video link.",
            });
            return;
        }
        
        let newSubjects = subjects.map(s => {
            if (s.id === subjectId) {
                return {
                    ...s,
                    chapters: s.chapters.map(c => {
                        if(c.id === chapterId) {
                            return {
                                ...c,
                                lectures: c.lectures.map(l => {
                                    if(l.id === lectureId) {
                                        return { ...l, videoId: videoId };
                                    }
                                    return l;
                                })
                            }
                        }
                        return c;
                    })
                }
            }
            return s;
        });

        setSubjects(newSubjects);
        toast({
            title: "Lecture Updated",
            description: "The video link has been successfully updated.",
        });
    }

    setEditItem(null);
    setEditedVideoUrl('');
  };
  
  const handleOpenAddChapter = (subjectId: string) => {
    setAddChapterState({ open: true, subjectId });
  };

  const handleCloseAddChapter = () => {
    setAddChapterState(null);
    setNewChapterTitle('');
  };

  const handleAddChapter = () => {
    if (!addChapterState || !newChapterTitle) {
      toast({ variant: 'destructive', title: 'Please enter a chapter name.' });
      return;
    }

    const newChapter: Chapter = {
      id: `c-${Date.now()}`,
      title: newChapterTitle,
      description: '', // Empty description as requested
      lectures: [],
    };

    const newSubjects = subjects.map(s => {
      if (s.id === addChapterState.subjectId) {
        return {
          ...s,
          chapters: [...s.chapters, newChapter],
        };
      }
      return s;
    });

    setSubjects(newSubjects);
    toast({ title: 'Chapter Added', description: `"${newChapter.title}" has been added.` });
    handleCloseAddChapter();
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
            <CardTitle className="font-headline text-2xl">Content Management</CardTitle>
            <CardDescription>Manage subjects, chapters, and lectures.</CardDescription>
        </div>
        <Button onClick={handleAddSubject}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Subject
        </Button>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible className="w-full">
          {subjects.map((subject) => (
            <AccordionItem value={subject.id} key={subject.id}>
              <AccordionTrigger className="text-lg font-headline hover:no-underline">
                <div className="flex items-center gap-4">
                  <subject.icon className="h-6 w-6 text-primary" />
                  {subject.name_hi} ({subject.name})
                </div>
              </AccordionTrigger>
              <AccordionContent className="pl-4">
                <div className="flex justify-between items-center mb-4">
                    <h4 className="font-semibold">Chapters</h4>
                    <Button variant="outline" size="sm" onClick={() => handleOpenAddChapter(subject.id)}>
                        <PlusCircle className="mr-2 h-4 w-4" /> Add Chapter
                    </Button>
                </div>
                <div className="space-y-4">
                  {subject.chapters.map((chapter) => (
                    <Card key={chapter.id} className="bg-muted/50">
                      <CardHeader className="flex flex-row items-center justify-between p-4">
                        <div className="flex items-center gap-3">
                           <Book className="h-5 w-5 text-muted-foreground"/>
                           <p className="font-semibold">{chapter.title}</p>
                        </div>
                        <div className="flex gap-2">
                           <Button variant="ghost" size="icon" onClick={() => toast({ title: "Feature not implemented", description: "Editing chapters is a planned feature."})}><Edit className="h-4 w-4" /></Button>
                           <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive" onClick={() => toast({ title: "Feature not implemented" })}><Trash2 className="h-4 w-4" /></Button>
                        </div>
                      </CardHeader>
                      <CardContent className="p-4 pt-0">
                         <h5 className="font-semibold mb-2 text-sm">Lectures</h5>
                         <div className="space-y-2">
                            {chapter.lectures.map(lecture => (
                                <div key={lecture.id} className="flex items-center justify-between text-sm p-2 rounded-md bg-background">
                                    <div className="flex items-center gap-2">
                                        <FileVideo className="h-4 w-4 text-muted-foreground"/>
                                        <span>{lecture.title}</span>
                                    </div>
                                    <div className="flex gap-1">
                                       <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleEdit({type: 'Lecture', subjectId: subject.id, chapterId: chapter.id, lectureId: lecture.id, data: lecture})}><Edit className="h-4 w-4" /></Button>
                                       <AlertDialog>
                                            <AlertDialogTrigger asChild>
                                                <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive"><Trash2 className="h-4 w-4" /></Button>
                                            </AlertDialogTrigger>
                                            <AlertDialogContent>
                                                <AlertDialogHeader>
                                                    <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                                    <AlertDialogDescription>
                                                        This action cannot be undone. This will permanently delete the lecture "{lecture.title}".
                                                    </AlertDialogDescription>
                                                </AlertDialogHeader>
                                                <AlertDialogFooter>
                                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                                    <AlertDialogAction onClick={() => handleDelete('Lecture', subject.id, chapter.id, lecture.id)}>Delete</AlertDialogAction>
                                                </AlertDialogFooter>
                                            </AlertDialogContent>
                                        </AlertDialog>
                                    </div>
                                </div>
                            ))}
                         </div>
                         <Button variant="outline" size="sm" className="mt-4 w-full" onClick={() => handleOpenAddLecture(subject.id, chapter.id)}>
                            <PlusCircle className="mr-2 h-4 w-4" /> Add Lecture
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </CardContent>

      <Dialog open={!!editItem} onOpenChange={(isOpen) => !isOpen && setEditItem(null)}>
        <DialogContent>
            {editItem && editItem.type === 'Lecture' && (
                <>
                <DialogHeader>
                    <DialogTitle>Edit Lecture</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="lecture-title" className="text-right">Title</Label>
                        <Input id="lecture-title" value={(editItem.data as Lecture).title} className="col-span-3" disabled />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="video-id" className="text-right">YouTube Video Link</Label>
                        <Input id="video-id" value={editedVideoUrl} onChange={(e) => setEditedVideoUrl(e.target.value)} className="col-span-3" />
                    </div>
                </div>
                <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setEditItem(null)}>Cancel</Button>
                    <Button type="submit" onClick={handleSaveEdit}>Save changes</Button>
                </DialogFooter>
                </>
            )}
        </DialogContent>
      </Dialog>
      
      <Dialog open={!!addLectureState?.open} onOpenChange={(isOpen) => !isOpen && handleCloseAddLecture()}>
        <DialogContent>
            <DialogHeader>
                <DialogTitle>Add New Lecture</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="new-lecture-title" className="text-right">Title</Label>
                    <Input id="new-lecture-title" value={newLectureTitle} onChange={e => setNewLectureTitle(e.target.value)} className="col-span-3" placeholder="e.g. Introduction to ..."/>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="new-video-link" className="text-right">YouTube Link</Label>
                    <Input id="new-video-link" value={newLectureLink} onChange={e => setNewLectureLink(e.target.value)} className="col-span-3" placeholder="https://www.youtube.com/watch?v=..."/>
                </div>
            </div>
            <DialogFooter>
                <Button type="button" variant="outline" onClick={handleCloseAddLecture}>Cancel</Button>
                <Button type="submit" onClick={handleAddLecture}>Add Lecture</Button>
            </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!addChapterState?.open} onOpenChange={(isOpen) => !isOpen && handleCloseAddChapter()}>
        <DialogContent>
            <DialogHeader>
                <DialogTitle>Add New Chapter</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="new-chapter-title" className="text-right">Chapter Name</Label>
                    <Input id="new-chapter-title" value={newChapterTitle} onChange={e => setNewChapterTitle(e.target.value)} className="col-span-3" placeholder="e.g. Real Numbers"/>
                </div>
            </div>
            <DialogFooter>
                <Button type="button" variant="outline" onClick={handleCloseAddChapter}>Cancel</Button>
                <Button type="submit" onClick={handleAddChapter}>Add Chapter</Button>
            </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
