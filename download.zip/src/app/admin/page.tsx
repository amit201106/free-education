'use client';

import { useState } from 'react';
import Header from "@/components/header";
import AdminDashboard from "./admin-dashboard";
import LoginForm from './login-form';

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleLoginSuccess = () => {
    setIsAuthenticated(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8 md:px-6">
        {!isAuthenticated ? (
          <>
            <h1 className="text-4xl font-bold font-headline mb-8 text-center">Admin Login</h1>
            <LoginForm onLoginSuccess={handleLoginSuccess} />
          </>
        ) : (
          <>
            <h1 className="text-4xl font-bold font-headline mb-8">Admin Panel</h1>
            <AdminDashboard />
          </>
        )}
      </main>
    </div>
  );
}
