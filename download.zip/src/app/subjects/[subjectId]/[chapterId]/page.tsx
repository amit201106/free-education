import { notFound } from 'next/navigation';
import { getChapterById } from '@/lib/data';
import Header from '@/components/header';
import LectureView from '@/components/lecture-view';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "@/components/ui/breadcrumb";

type ChapterPageProps = {
  params: {
    subjectId: string;
    chapterId: string;
  };
};

export default function ChapterPage({ params }: ChapterPageProps) {
  const chapter = getChapterById(params.subjectId, params.chapterId);

  if (!chapter) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8 md:px-6">
        <Breadcrumb className="mb-8">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/">Home</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbLink href={`/subjects/${params.subjectId}`}>{params.subjectId.charAt(0).toUpperCase() + params.subjectId.slice(1)}</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>{chapter.title}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        
        <header className="mb-8">
            <h1 className="text-4xl font-bold font-headline">{chapter.title}</h1>
            <p className="text-lg text-muted-foreground mt-2">{chapter.description}</p>
        </header>

        <LectureView chapter={chapter} />
      </main>
    </div>
  );
}
