import { notFound } from 'next/navigation';
import { getSubjectById } from '@/lib/data';
import Header from '@/components/header';
import ChapterListItem from '@/components/chapter-list-item';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "@/components/ui/breadcrumb";
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

type SubjectPageProps = {
  params: {
    subjectId: string;
  };
};

export default function SubjectPage({ params }: SubjectPageProps) {
  const subject = getSubjectById(params.subjectId);

  if (!subject) {
    notFound();
  }

  const { icon: SubjectIcon } = subject;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8 md:px-6">
        <Breadcrumb className="mb-8">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/">Home</BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>{subject.name}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        
        <header className="mb-12 flex items-center gap-4">
            <div className="bg-primary/10 text-primary p-4 rounded-xl">
                <SubjectIcon className="h-10 w-10" />
            </div>
            <div>
                <h1 className="text-4xl font-bold font-headline">{subject.name_hi}</h1>
                <p className="text-xl text-muted-foreground">{subject.name}</p>
            </div>
        </header>

        <Card>
            <CardHeader>
                <CardTitle className="font-headline text-2xl">Chapters</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    {subject.chapters.map((chapter) => (
                        <ChapterListItem key={chapter.id} subjectId={subject.id} chapter={chapter} />
                    ))}
                </div>
            </CardContent>
        </Card>
      </main>
    </div>
  );
}
